# Normalization and scaling ledger

## Frozen symbols

- Dimension: \(d\).
- Riesz exponent: \(0<s<d\); log separate.
- Particle number: \(N\).
- Inverse temperature: \(\beta_N\).
- Effective microscopic coupling:
  \[
  \lambda_N=\beta_NN^{s/d-1}.
  \]
- Empirical measure:
  \[
  \mu_N=N^{-1}\sum_{i=1}^N\delta_{x_i}.
  \]
- Fluctuation discrepancy: \(\rho_N=\mu_N-\mu\).
- Fluctuation scale: record theorem by theorem; thermal candidate \(\sqrt{N\beta_N}\), initial candidate \(\kappa_N\), combined scale must be frozen explicitly.

## Regime table

| Regime | Condition | Equivalent beta scale | Status |
|---|---|---|---|
| Old pathwise sufficient | \(\beta_NN^{2s/d-1}\to0\) | \(\beta_N\ll N^{1-2s/d}\) | existing baseline to supersede |
| Full subcritical | \(\lambda_N\to0\) | \(\beta_N\ll N^{1-s/d}\) | target |
| Critical | \(\lambda_N\to\lambda\in(0,\infty)\) | \(\beta_N\sim\lambda N^{1-s/d}\) | target |
| Supercritical | \(\lambda_N\to\infty\) | \(\beta_N\gg N^{1-s/d}\) | sharpness |

## Required additions

For every active theorem, append:

- exact Hamiltonian convention;
- factor of \(1/N\) in pair interaction;
- Brownian coefficient;
- deleted diagonal convention;
- periodic Fourier normalization;
- modulated energy factor \(1/2\);
- test-function normalization;
- corrector coefficient;
- centering and counterterms;
- error after multiplication by the fluctuation scale.


## Round 001 v1.0 freeze (2026-09-17)

Authoritative common dossier: `TASKS/ACTIVE/ROUND_001_MODEL.md`; baseline `475a5399828bc6e2ccbade08c59b8778638df14a`.

- Unit torus, Haar mass one, Fourier characters exp(2 pi i k.x); zero mode of g is zero. Fixed smooth even kernel first; singular target is heat-regularized Riesz with the explicit Fourier coefficient in the dossier. Fourier constant is separately source-audited before use.
- Hamiltonian H_N=sum_i V(x_i)+(1/(2N))sum_{i!=j}g(x_i-x_j); gradient drift is -grad_i H_N; Brownian coefficient sqrt(2/beta_N). Its formal invariant Gibbs density is exp(-beta_N H_N), but no equilibrium/dynamic transfer is used.
- nu_N=1/beta_N; reference mu^{N,g} retains temperature and kernel dependence. Smooth positivity is assumed on the finite horizon, not claimed uniformly without stated bounds.
- Empirical measure eta=N^{-1}sum delta_i, rho=eta-mu. Ordered distinct-label tuples, denominators N^k, not (N)_k. Label deletion is meaningful even at coincident coordinates for smooth kernels.
- P_N=U_2/2. General U_k is the precise inclusion-exclusion statistic in the dossier. Background centering is not mean-zero under iid laws: E U_2[Phi]=-mu_0^2(Phi)/N at t=0. For constant Phi=1, U_2=-1/N and U_3=2/N^2.
- sigma_N=min(sqrt(N beta_N),kappa_N); iid row has kappa_N=sqrt(N). Do not replace this by the thermal scale when beta_N grows.
- Initial laws are arbitrary for finite-N pathwise identities, exchangeable when deriving marginals; iid and Gibbs fluctuation theorems remain distinct and open.
- For fixed smooth g, the Riesz reference exponent s labels a sequence but does not create a microscopic singularity. Fixed-cutoff bounds cannot be used to infer lambda_N critical power counting.
- Logarithmic normalization remains separately OPEN. No s=0 substitution.

## Ordered-source temperature map

In dimension one, V=0, source H=N^{-s} sum_{i!=j}g has Gibbs density exp(-b H). Campaign energy is (2N)^{-1} sum_{i!=j}g, so b=beta_N N^{s-1}/2=lambda_N/2. No ordered/unordered factor is suppressed. The source real-space kernel has exactly the campaign Fourier constant; its separately printed fractional-Laplacian c_s is inconsistent and is not adopted. Frozen campaign exponents and Fourier coefficients remain unchanged.
